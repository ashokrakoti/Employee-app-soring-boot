package com.evoke.employee.controller

import com.evoke.employee.entities.Employee
import com.evoke.employee.service.IEmployeeService
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.DeleteMapping
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.PutMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/v1")
class EmployeeController {
    Logger logger = LoggerFactory.getLogger(EmployeeController.class)

    @Autowired
    IEmployeeService iEmployeeService ;

    //save employee
    @PostMapping("/employee")
    ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee){

        return new ResponseEntity<Employee>(iEmployeeService.save(employee),HttpStatus.OK)
    }

    //get employee by id
    @GetMapping("/employee/{id}")
    ResponseEntity<Employee> getEmployeeById(@PathVariable long id){

        return new ResponseEntity<>(iEmployeeService.getEmployeeById(id), HttpStatus.OK)
    }

   //get all employees
    @GetMapping("/employees")
    ResponseEntity<List<Employee>> getAllEmployees(){
         return new ResponseEntity<>(iEmployeeService.getAllEmployees(), HttpStatus.OK)
    }

    @PutMapping("/employee/{id}")
    ResponseEntity<Employee> updateEmployee(@RequestBody Employee emp, @PathVariable Long id){
        return new ResponseEntity<Employee>(iEmployeeService.updateEmployee(emp, id), HttpStatus.OK)
    }

    @DeleteMapping("/employee/{id}")
    ResponseEntity<Employee> deleteEmployeeById(@PathVariable Long id){

        return new ResponseEntity<Employee>(iEmployeeService.removeEmployee(id), HttpStatus.OK)
    }

}
