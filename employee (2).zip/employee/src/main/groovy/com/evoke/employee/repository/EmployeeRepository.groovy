package com.evoke.employee.repository

import com.evoke.employee.entities.Employee
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface EmployeeRepository extends JpaRepository<Employee, Long>{

    Employee findEmployeeById(Long empID)

    List<Employee> findAll()

    Employee save(Employee emp)

    void deleteById(Long id)



}
