package com.evoke.employee.service

import com.evoke.employee.entities.Employee
import com.evoke.employee.repository.EmployeeRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class EmployeeServiceImpl implements IEmployeeService{

    @Autowired
    EmployeeRepository employeeRepository

    @Override
    List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    Employee getEmployeeById(long id) {
        println ("employee:: "+employeeRepository.findEmployeeById(id))
        return employeeRepository.findEmployeeById(id)
    }

    @Override
    Employee save(Employee emp) {
        return employeeRepository.save(emp)
    }

    @Override
    Employee removeEmployee(Long id) {

          def employee = employeeRepository.findEmployeeById(id)
          if(employee!=null){
              employeeRepository.delete(employee)
          }
        return employee
    }

    @Override
    Employee updateEmployee(Employee emp, Long id) {
        //find the emp with id passed
        Employee employee = employeeRepository.findEmployeeById(id)
        emp.setId(employee.getId())
        emp.setCreated_on(new Date(System.currentTimeMillis()))
        return employeeRepository.save(emp)
    }
}
