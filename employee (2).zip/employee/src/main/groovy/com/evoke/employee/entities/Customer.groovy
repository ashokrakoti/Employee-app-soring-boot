package com.evoke.employee.entities

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id

@Entity
class Customer implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
     private long id

    @Column(name = "firstName")
     private String firstName

    @Column(name = "lastName")
     private String LastName

    Customer( String firstName, String lastName) {
        this.firstName = firstName
        LastName = lastName
    }

    long getId() {
        return id
    }

    void setId(long id) {
        this.id = id
    }

    String getFirstName() {
        return firstName
    }

    void setFirstName(String firstName) {
        this.firstName = firstName
    }

    String getLastName() {
        return LastName
    }

    void setLastName(String lastName) {
        LastName = lastName
    }
}
