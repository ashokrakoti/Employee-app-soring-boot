package com.evoke.employee.entities

import org.springframework.data.annotation.CreatedDate

import javax.persistence.Column
import javax.persistence.Entity
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType
import javax.persistence.Id
import javax.persistence.PrePersist
import javax.persistence.Table
import javax.persistence.Temporal
import javax.persistence.TemporalType

@Entity
@Table(name="Employee")
class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id

    @Column(name="name")
    private String name

    @Column(name="phone")
    private String phone

    @Column(name="created_by")
    private String created_by

    @Temporal(TemporalType.TIMESTAMP)
    private Date created_on

    @PrePersist
    private void onCreate() {
        created_on = new Date(System.currentTimeMillis())
    }

    Employee() {
    }

    Employee(long id, String name, String phone, String created_by, Date created_on) {
        this.id = id
        this.name = name
        this.phone = phone
        this.created_by = created_by
        this.created_on = created_on
    }

    Employee( String name, String phone, String created_by) {
        this.name = name
        this.phone = phone
        this.created_by = created_by
    }

    long getId() {
        return id
    }

    void setId(long id) {
        this.id = id
    }

    String getName() {
        return name
    }

    void setName(String name) {
        this.name = name
    }

    String getPhone() {
        return phone
    }

    void setPhone(String phone) {
        this.phone = phone
    }

    String getCreated_by() {
        return created_by
    }

    void setCreated_by(String created_by) {
        this.created_by = created_by
    }

    Date getCreated_on() {
        return created_on
    }

    void setCreated_on(Date created_on) {
        this.created_on = created_on
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", created_by='" + created_by + '\'' +
                ", created_on=" + created_on +
                '}';
    }
}
