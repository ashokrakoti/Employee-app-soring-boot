package com.evoke.employee.controller

import com.evoke.employee.entities.Customer
import com.evoke.employee.repository.CustomerRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class CustomerController {

    @Autowired
    CustomerRepository repository

    @GetMapping("/bulk-create")
    ResponseEntity<List<Customer>> bulkCreate(){
        repository.save(new Customer("Rajesh", "Bhojwani"))

        //save multiple customers at once
        List<Customer> customers = repository.saveAll(Arrays.asList(new Customer("Salim", "Khan")
                                        , new Customer("Ramesh", "Kumar")
                                        , new Customer("Anjali", "Rajput")
                                        , new Customer("Shibu","Solomon")));

        return new ResponseEntity<>(customers, HttpStatus.OK);
    }


}
