package com.evoke.employee.repository

import com.evoke.employee.entities.Customer
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface CustomerRepository extends JpaRepository<Customer, Long>{

    List<Customer> findByFirstName(String FirstName)
    List<Customer> findAll()
}