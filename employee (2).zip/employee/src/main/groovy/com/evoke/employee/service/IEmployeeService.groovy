package com.evoke.employee.service

import com.evoke.employee.entities.Employee
import org.springframework.stereotype.Service


interface IEmployeeService {

    //retrieve all employees list
    List<Employee> getAllEmployees()

    //get employee by id
    Employee getEmployeeById(long id)

    //save new employee
    Employee save(Employee emp)

    //delete employee
    Employee removeEmployee(Long id)

    Employee updateEmployee(Employee emp, Long id)

}